SupeRR Selector Season 2 - Round 1 submission bundle

Methodology_Report.docx            the report (top 10 lists)
Methodology_Report_Extended.docx   same report with a clickable contents page and top-30 lists
01..07_*.ipynb                     analysis notebooks, run in numeric order
ratings_lib.py                     shared rating code used by notebooks 06 and 07
final_top10_*.csv                  the two final top-10 lists
final_ratings_*.csv                full rating tables for eligible players (ranks 1 to N)
*_min60.csv                        earlier 60-ball-minimum version, for comparison

To re-run: put ball_by_ball.csv, matches.csv, competitions.csv, teams.csv and
competition_team_player_mapping.csv in the same folder, then run notebooks 01 to 07.
Python packages: pandas, numpy, scikit-learn, matplotlib, jupyter.
