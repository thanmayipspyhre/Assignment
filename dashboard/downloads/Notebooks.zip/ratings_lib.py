"""Shared rating code for Steps 5-7 (same method as 05_player_ratings.ipynb, rewritten on per-player-per-match sums
so it can be re-run thousands of times on resampled matches)."""
import numpy as np
import pandas as pd

CTX = ["innings", "bl_band", "wk_band", "is_ipl", "pace_or_spin"]
MINS = (60, 8, 120)      # pressure balls, matches with pressure balls, ordinary balls
MINS_H = (100, 8, 120)   # Step 7 eligibility: raised to 100 pressure balls
POOL = (30, 60)          # players used to estimate the shrinkage prior


def load(path="match_state_pressure.csv", flag="pC"):
    d = pd.read_csv(path, low_memory=False)
    d["pace_or_spin"] = d.pace_or_spin.fillna("Unk")
    d["bl_band"] = pd.cut(d.balls_left, [0, 6, 12, 18, 24, 36, 48, 60, 72, 84, 96, 108, 120]).astype(str)
    d["wk_band"] = d.wkts_before.clip(upper=7)
    d["bat_wk"] = (d.dismissed_player_id == d.striker_id).astype(int)
    dt = d.dismissal_type.fillna("").str.lower()
    d["bowl_wk"] = ((d.wkt == 1) & ~dt.str.contains("run out|retired|obstruct")).astype(int)

    bp = d[(d.legal == 1) & (d[flag] == 1)]
    X = np.column_stack([np.ones(len(bp)), bp.runs, bp.bat_wk, (bp.innings == 2).astype(int)])
    coef, *_ = np.linalg.lstsq(X, bp.wpa.values, rcond=None)
    lam = -coef[2] / coef[1]

    B = d[d.legal == 1].copy()
    B["e_runs"] = B.groupby(CTX).runs.transform("mean")
    B["e_wk"] = B.groupby(CTX).bat_wk.transform("mean")
    B["rv"] = (B.runs - B.e_runs) - lam * (B.bat_wk - B.e_wk)
    B["val"] = B.wpa
    W = d.copy()
    W["e_runs"] = W.groupby(CTX).tot.transform("mean")
    W["e_wk"] = W.groupby(CTX).bowl_wk.transform("mean")
    W["rv"] = (W.e_runs - W.tot) + lam * (W.bowl_wk - W.e_wk)
    W["val"] = -W.wpa
    return B, W, lam


class PM:
    """Per (player, match) sufficient statistics, as dense players x matches arrays."""

    def __init__(self, F, pid, pname, flag="pC"):
        self.matches = np.sort(F.match_id.unique())
        mi = pd.Series(np.arange(len(self.matches)), index=self.matches)
        self.players = np.sort(F[pid].unique())
        pi = pd.Series(np.arange(len(self.players)), index=self.players)
        self.names = F.groupby(pid)[pname].first().reindex(self.players)
        F = F.assign(_r=F.rv ** 2, _v=F.val ** 2, _pr=F[flag])
        shp = (len(self.players), len(self.matches))

        def dense(sub, col):
            g = sub.groupby([pid, "match_id"])[col].sum()
            a = np.zeros(shp)
            a[pi[g.index.get_level_values(0)].values, mi[g.index.get_level_values(1)].values] = g.values
            return a
        p, o = F[F._pr == 1], F[F._pr == 0]
        one = lambda s: s.assign(_one=1.0)
        p, o = one(p), one(o)
        self.n_p, self.sv_p, self.ssv_p = dense(p, "_one"), dense(p, "val"), dense(p, "_v")
        self.sr_p, self.ssr_p = dense(p, "rv"), dense(p, "_r")
        self.n_o, self.sr_o, self.ssr_o = dense(o, "_one"), dense(o, "rv"), dense(o, "_r")
        ipl = F.groupby("match_id").is_ipl.first().reindex(self.matches).values
        self.match_ipl = ipl


def eb(obs, se2):
    obs, se2 = np.asarray(obs, float), np.asarray(se2, float)
    mu, tau2 = obs.mean(), max(obs.var(), 1e-9)
    for _ in range(20):
        w = 1 / (se2 + tau2)
        mu = (w * obs).sum() / w.sum()
        tau2 = max(((obs - mu) ** 2).mean() - se2.mean(), 1e-6)
    return mu, tau2


def rate(P, w, mins=MINS, pool=POOL, wv=0.5):
    """Ratings from match weights w (1/0 mask or bootstrap counts). Returns DataFrame indexed by player id."""
    w = np.asarray(w, float)
    n_p, n_o = P.n_p @ w, P.n_o @ w
    m_p = (P.n_p > 0).astype(float) @ w
    sv, ssv, sr, ssr = P.sv_p @ w, P.ssv_p @ w, P.sr_p @ w, P.ssr_p @ w
    sro, ssro = P.sr_o @ w, P.ssr_o @ w
    N, No = n_p.sum(), n_o.sum()
    s2_val = (ssv.sum() - sv.sum() ** 2 / N) / (N - 1)
    s2_rp = (ssr.sum() - sr.sum() ** 2 / N) / (N - 1)
    s2_ro = (ssro.sum() - sro.sum() ** 2 / No) / (No - 1)
    ok = (n_p > 0) & (n_o > 0)
    t = pd.DataFrame(index=P.players[ok])
    t["name"] = P.names.values[ok]
    t["n_p"], t["n_o"], t["m_p"] = n_p[ok], n_o[ok], m_p[ok]
    t["PV_raw"] = sv[ok] / n_p[ok] * 100
    t["PV_se2"] = s2_val * 1e4 / n_p[ok]
    t["PD_raw"] = (sr[ok] / n_p[ok] - sro[ok] / n_o[ok]) * 100
    t["PD_se2"] = (s2_rp / n_p[ok] + s2_ro / n_o[ok]) * 1e4
    pl = (t.n_p >= pool[0]) & (t.n_o >= pool[1])
    for c in ["PV", "PD"]:
        mu, tau2 = eb(t.loc[pl, f"{c}_raw"], t.loc[pl, f"{c}_se2"])
        t[c] = mu + tau2 / (tau2 + t[f"{c}_se2"]) * (t[f"{c}_raw"] - mu)
    t["eligible"] = (t.n_p >= mins[0]) & (t.m_p >= mins[1]) & (t.n_o >= mins[2])
    e = t.eligible
    for c in ["PV", "PD"]:
        t.loc[e, f"z{c}"] = (t.loc[e, c] - t.loc[e, c].mean()) / t.loc[e, c].std()
    t["rating"] = wv * t.zPV + (1 - wv) * t.zPD
    t["rank"] = t.rating.rank(ascending=False)
    return t


def rate_h(P, w, mins=MINS_H, pool=POOL):
    """Step 7 hierarchical rating (runs per 100 balls, context-adjusted).
    Prior for a player's pressure level = a + b * (shrunk usual level); the player's own pressure evidence then pulls the
    estimate away from that prior by tau2/(tau2+se2). a, b, tau2 are fitted on the data (weighted regression + method of moments)."""
    w = np.asarray(w, float)
    n_p, n_o = P.n_p @ w, P.n_o @ w
    m_p = (P.n_p > 0).astype(float) @ w
    sr, ssr, sro, ssro = P.sr_p @ w, P.ssr_p @ w, P.sr_o @ w, P.ssr_o @ w
    N, No = n_p.sum(), n_o.sum()
    s2p = (ssr.sum() - sr.sum() ** 2 / N) / (N - 1)
    s2o = (ssro.sum() - sro.sum() ** 2 / No) / (No - 1)
    ok = (n_p > 0) & (n_o > 0)
    t = pd.DataFrame(index=P.players[ok])
    t["name"] = P.names.values[ok]
    t["n_p"], t["n_o"], t["m_p"] = n_p[ok], n_o[ok], m_p[ok]
    t["Pr_raw"], t["Pr_se2"] = sr[ok] / n_p[ok] * 100, s2p * 1e4 / n_p[ok]
    t["U_raw"], t["U_se2"] = sro[ok] / n_o[ok] * 100, s2o * 1e4 / n_o[ok]
    pl = ((t.n_p >= pool[0]) & (t.n_o >= pool[1])).values
    muU, tauU2 = eb(t.U_raw[pl], t.U_se2[pl])
    t["U"] = muU + tauU2 / (tauU2 + t.U_se2) * (t.U_raw - muU)
    x, y, se = t.U.values[pl], t.Pr_raw.values[pl], t.Pr_se2.values[pl]
    X = np.column_stack([np.ones(len(x)), x])
    tau2 = max(y.var(), 1e-6)
    for _ in range(30):
        wt = 1 / (se + tau2)
        coef = np.linalg.solve(X.T @ (X * wt[:, None]), X.T @ (wt * y))
        res = y - X @ coef
        tau2 = max((res ** 2).mean() - se.mean(), 1e-6)
    a, b = coef
    t["prior"] = a + b * t.U
    t["w_pressure"] = tau2 / (tau2 + t.Pr_se2)
    t["theta"] = t.prior + t.w_pressure * (t.Pr_raw - t.prior)
    t["eligible"] = (t.n_p >= mins[0]) & (t.m_p >= mins[1]) & (t.n_o >= mins[2])
    t["rating"] = t.theta
    t["rank"] = t.loc[t.eligible, "rating"].rank(ascending=False).reindex(t.index)
    t.attrs.update(a=a, b=b, tau=tau2 ** 0.5, muU=muU, tauU=tauU2 ** 0.5)
    return t
